 .Sol file Watershed HRU:111 Subbasin:4 HRU:34 Luse:PINE Soil: CO565A Slope: 10.0-25.0 4/16/2025 12:00:00 AM ArcSWAT 2012.10_7.23
 Soil Name: CO565A
 Soil Hydrologic Group: B
 Maximum rooting depth(mm) :  700.00
 Porosity fraction from which anions are excluded: 0.500
 Crack volume potential of soil: 0.500
 Texture 1                : FAGr-Agr
 Depth                [mm]:      500.00      700.00
 Bulk Density Moist [g/cc]:        1.48        1.39
 Ave. AW Incl. Rock Frag  :        0.32        0.32
 Ksat. (est.)      [mm/hr]:       46.76      145.25
 Organic Carbon [weight %]:        6.70        6.50
 Clay           [weight %]:       16.00        4.00
 Silt           [weight %]:       16.00        6.00
 Sand           [weight %]:       68.00       90.00
 Rock Fragments   [vol. %]:        1.00        1.00
 Soil Albedo (Moist)      :        0.13        0.13
 Erosion K                :        0.15        0.08
 Salinity (EC, Form 5)    :        0.00        0.00
 Soil pH                  :        0.00        0.00
 Soil CACO3               :        0.00        0.00
                              
