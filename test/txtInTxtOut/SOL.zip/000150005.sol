 .Sol file Watershed HRU:457 Subbasin:15 HRU:5 Luse:FRST Soil: CO563 Slope: 10.0-25.0 4/16/2025 12:00:00 AM ArcSWAT 2012.10_7.23
 Soil Name: CO563
 Soil Hydrologic Group: B
 Maximum rooting depth(mm) : 1500.00
 Porosity fraction from which anions are excluded: 0.500
 Crack volume potential of soil: 0.500
 Texture 1                : FArA-FA-FA-FA
 Depth                [mm]:      220.00      420.00      740.00     1500.00
 Bulk Density Moist [g/cc]:        1.47        1.46        1.45        1.46
 Ave. AW Incl. Rock Frag  :        0.32        0.32        0.32        0.32
 Ksat. (est.)      [mm/hr]:       32.62       38.73       63.51       63.87
 Organic Carbon [weight %]:        6.70        6.50        6.10        6.10
 Clay           [weight %]:       20.00       18.00       12.00       12.00
 Silt           [weight %]:       22.00       24.00       24.00       22.00
 Sand           [weight %]:       58.00       58.00       64.00       66.00
 Rock Fragments   [vol. %]:        1.00        1.00        1.00        1.00
 Soil Albedo (Moist)      :        0.13        0.13        0.13        0.13
 Erosion K                :        0.16        0.17        0.17        0.17
 Salinity (EC, Form 5)    :        0.00        0.00        0.00        0.00
 Soil pH                  :        0.00        0.00        0.00        0.00
 Soil CACO3               :        0.00        0.00        0.00        0.00
                              
