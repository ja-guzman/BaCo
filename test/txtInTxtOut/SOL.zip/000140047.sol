 .Sol file Watershed HRU:452 Subbasin:14 HRU:47 Luse:PINE Soil: CO561A Slope: 25.0-50.0 4/16/2025 12:00:00 AM ArcSWAT 2012.10_7.23
 Soil Name: CO561A
 Soil Hydrologic Group: B
 Maximum rooting depth(mm) : 1500.00
 Porosity fraction from which anions are excluded: 0.500
 Crack volume potential of soil: 0.500
 Texture 1                : FArAGr-FArGr-ArGr
 Depth                [mm]:      310.00      670.00     1500.00
 Bulk Density Moist [g/cc]:        1.48        1.53        1.48
 Ave. AW Incl. Rock Frag  :        0.32        0.32        0.32
 Ksat. (est.)      [mm/hr]:       26.96        7.10        3.65
 Organic Carbon [weight %]:        6.70        6.50        6.10
 Clay           [weight %]:       22.00       36.00       50.00
 Silt           [weight %]:       22.00       24.00       30.00
 Sand           [weight %]:       56.00       40.00       20.00
 Rock Fragments   [vol. %]:        1.00        1.00        1.00
 Soil Albedo (Moist)      :        0.13        0.13        0.13
 Erosion K                :        0.16        0.15        0.16
 Salinity (EC, Form 5)    :        0.00        0.00        0.00
 Soil pH                  :        0.00        0.00        0.00
 Soil CACO3               :        0.00        0.00        0.00
                              
