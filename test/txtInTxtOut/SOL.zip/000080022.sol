 .Sol file Watershed HRU:238 Subbasin:8 HRU:22 Luse:MESQ Soil: CO566A Slope: 25.0-50.0 4/16/2025 12:00:00 AM ArcSWAT 2012.10_7.23
 Soil Name: CO566A
 Soil Hydrologic Group: B
 Maximum rooting depth(mm) : 1500.00
 Porosity fraction from which anions are excluded: 0.500
 Crack volume potential of soil: 0.500
 Texture 1                : FArA-FArA-FArA
 Depth                [mm]:      230.00      660.00     1500.00
 Bulk Density Moist [g/cc]:        1.47        1.49        1.55
 Ave. AW Incl. Rock Frag  :        0.32        0.32        0.32
 Ksat. (est.)      [mm/hr]:       27.45       26.29       16.40
 Organic Carbon [weight %]:        6.70        6.50        6.10
 Clay           [weight %]:       22.00       22.00       26.00
 Silt           [weight %]:       24.00       22.00       20.00
 Sand           [weight %]:       54.00       56.00       54.00
 Rock Fragments   [vol. %]:        1.00        1.00        1.00
 Soil Albedo (Moist)      :        0.13        0.13        0.13
 Erosion K                :        0.16        0.16        0.16
 Salinity (EC, Form 5)    :        0.00        0.00        0.00
 Soil pH                  :        0.00        0.00        0.00
 Soil CACO3               :        0.00        0.00        0.00
                              
