 .Sol file Watershed HRU:196 Subbasin:7 HRU:11 Luse:FRST Soil: CO566B Slope: 50.0-9999 4/16/2025 12:00:00 AM ArcSWAT 2012.10_7.23
 Soil Name: CO566B
 Soil Hydrologic Group: B
 Maximum rooting depth(mm) : 1500.00
 Porosity fraction from which anions are excluded: 0.500
 Crack volume potential of soil: 0.500
 Texture 1                : FA-FA-FA-FA
 Depth                [mm]:      220.00      500.00      840.00     1500.00
 Bulk Density Moist [g/cc]:        1.42        1.47        1.42        1.40
 Ave. AW Incl. Rock Frag  :        0.32        0.32        0.32        0.32
 Ksat. (est.)      [mm/hr]:       56.81       38.46       91.02      106.90
 Organic Carbon [weight %]:        6.70        6.50        6.10        6.10
 Clay           [weight %]:       14.00       18.00        8.00        6.00
 Silt           [weight %]:       22.00       22.00       22.00       24.00
 Sand           [weight %]:       64.00       60.00       70.00       70.00
 Rock Fragments   [vol. %]:        1.00        1.00        1.00        1.00
 Soil Albedo (Moist)      :        0.13        0.13        0.13        0.13
 Erosion K                :        0.17        0.17        0.17        0.17
 Salinity (EC, Form 5)    :        0.00        0.00        0.00        0.00
 Soil pH                  :        0.00        0.00        0.00        0.00
 Soil CACO3               :        0.00        0.00        0.00        0.00
                              
