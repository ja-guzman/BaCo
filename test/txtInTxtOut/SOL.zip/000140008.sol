 .Sol file Watershed HRU:413 Subbasin:14 HRU:8 Luse:FESC Soil: CO561B Slope: 0-10.0 4/16/2025 12:00:00 AM ArcSWAT 2012.10_7.23
 Soil Name: CO561B
 Soil Hydrologic Group: B
 Maximum rooting depth(mm) : 1500.00
 Porosity fraction from which anions are excluded: 0.500
 Crack volume potential of soil: 0.500
 Texture 1                : FArGr-FArGr-FArAGr
 Depth                [mm]:      230.00      580.00     1500.00
 Bulk Density Moist [g/cc]:        1.45        1.51        1.51
 Ave. AW Incl. Rock Frag  :        0.32        0.32        0.32
 Ksat. (est.)      [mm/hr]:       13.19       13.06       21.35
 Organic Carbon [weight %]:        6.70        6.50        6.10
 Clay           [weight %]:       32.00       30.00       24.00
 Silt           [weight %]:       32.00       26.00       24.00
 Sand           [weight %]:       36.00       44.00       52.00
 Rock Fragments   [vol. %]:        1.00        1.00        1.00
 Soil Albedo (Moist)      :        0.13        0.13        0.13
 Erosion K                :        0.16        0.16        0.16
 Salinity (EC, Form 5)    :        0.00        0.00        0.00
 Soil pH                  :        0.00        0.00        0.00
 Soil CACO3               :        0.00        0.00        0.00
                              
