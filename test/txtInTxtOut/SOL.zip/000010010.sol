 .Sol file Watershed HRU:10 Subbasin:1 HRU:10 Luse:RNGB Soil: CO568 Slope: 25.0-50.0 4/16/2025 12:00:00 AM ArcSWAT 2012.10_7.23
 Soil Name: CO568
 Soil Hydrologic Group: B
 Maximum rooting depth(mm) :  850.00
 Porosity fraction from which anions are excluded: 0.500
 Crack volume potential of soil: 0.500
 Texture 1                : FAGr-FA-FA
 Depth                [mm]:      100.00      520.00      850.00
 Bulk Density Moist [g/cc]:        1.14        1.22        1.28
 Ave. AW Incl. Rock Frag  :        0.32        0.32        0.32
 Ksat. (est.)      [mm/hr]:       79.85       92.87       65.11
 Organic Carbon [weight %]:        6.70        6.50        6.10
 Clay           [weight %]:        8.00        6.00       10.00
 Silt           [weight %]:       16.00       10.00       14.00
 Sand           [weight %]:       76.00       84.00       76.00
 Rock Fragments   [vol. %]:        1.00        1.00        1.00
 Soil Albedo (Moist)      :        0.13        0.13        0.13
 Erosion K                :        0.15        0.11        0.14
 Salinity (EC, Form 5)    :        0.00        0.00        0.00
 Soil pH                  :        0.00        0.00        0.00
 Soil CACO3               :        0.00        0.00        0.00
                              
