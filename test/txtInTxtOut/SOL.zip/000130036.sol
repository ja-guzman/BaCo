 .Sol file Watershed HRU:402 Subbasin:13 HRU:36 Luse:FESC Soil: CO562 Slope: 0-10.0 4/16/2025 12:00:00 AM ArcSWAT 2012.10_7.23
 Soil Name: CO562
 Soil Hydrologic Group: B
 Maximum rooting depth(mm) : 1100.00
 Porosity fraction from which anions are excluded: 0.500
 Crack volume potential of soil: 0.500
 Texture 1                : FArAGr-FArGr
 Depth                [mm]:      470.00     1100.00
 Bulk Density Moist [g/cc]:        1.48        1.43
 Ave. AW Incl. Rock Frag  :        0.32        0.32
 Ksat. (est.)      [mm/hr]:       16.18       18.04
 Organic Carbon [weight %]:        6.70        6.50
 Clay           [weight %]:       28.00       28.00
 Silt           [weight %]:       26.00       34.00
 Sand           [weight %]:       46.00       38.00
 Rock Fragments   [vol. %]:        1.00        1.00
 Soil Albedo (Moist)      :        0.13        0.13
 Erosion K                :        0.16        0.17
 Salinity (EC, Form 5)    :        0.00        0.00
 Soil pH                  :        0.00        0.00
 Soil CACO3               :        0.00        0.00
                              
