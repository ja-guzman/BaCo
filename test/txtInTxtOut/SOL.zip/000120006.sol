 .Sol file Watershed HRU:341 Subbasin:12 HRU:6 Luse:MESQ Soil: CO564 Slope: 0-10.0 4/16/2025 12:00:00 AM ArcSWAT 2012.10_7.23
 Soil Name: CO564
 Soil Hydrologic Group: B
 Maximum rooting depth(mm) : 1000.00
 Porosity fraction from which anions are excluded: 0.500
 Crack volume potential of soil: 0.500
 Texture 1                : FA-FLGr-FA
 Depth                [mm]:      280.00      600.00     1000.00
 Bulk Density Moist [g/cc]:        1.43        1.39        1.36
 Ave. AW Incl. Rock Frag  :        0.32        0.32        0.32
 Ksat. (est.)      [mm/hr]:       40.01      115.54      124.85
 Organic Carbon [weight %]:        6.70        6.50        6.10
 Clay           [weight %]:       18.00        6.00        4.00
 Silt           [weight %]:       26.00       16.00       26.00
 Sand           [weight %]:       56.00       78.00       70.00
 Rock Fragments   [vol. %]:        1.00        1.00        1.00
 Soil Albedo (Moist)      :        0.13        0.13        0.13
 Erosion K                :        0.17        0.15        0.18
 Salinity (EC, Form 5)    :        0.00        0.00        0.00
 Soil pH                  :        0.00        0.00        0.00
 Soil CACO3               :        0.00        0.00        0.00
                              
