 .Sol file Watershed HRU:164 Subbasin:6 HRU:4 Luse:RYEG Soil: CO566C Slope: 25.0-50.0 4/16/2025 12:00:00 AM ArcSWAT 2012.10_7.23
 Soil Name: CO566C
 Soil Hydrologic Group: B
 Maximum rooting depth(mm) : 1500.00
 Porosity fraction from which anions are excluded: 0.500
 Crack volume potential of soil: 0.500
 Texture 1                : FAGr-FAGr-FArA-FArA
 Depth                [mm]:      250.00      560.00      860.00     1500.00
 Bulk Density Moist [g/cc]:        1.48        1.47        1.59        1.53
 Ave. AW Incl. Rock Frag  :        0.32        0.32        0.32        0.32
 Ksat. (est.)      [mm/hr]:       38.72       55.65        8.30       36.37
 Organic Carbon [weight %]:        6.70        6.50        6.10        6.10
 Clay           [weight %]:       18.00       14.00       32.00       18.00
 Silt           [weight %]:       18.00       18.00       18.00       18.00
 Sand           [weight %]:       64.00       68.00       50.00       64.00
 Rock Fragments   [vol. %]:        1.00        1.00        1.00        1.00
 Soil Albedo (Moist)      :        0.13        0.13        0.13        0.13
 Erosion K                :        0.16        0.16        0.15        0.16
 Salinity (EC, Form 5)    :        0.00        0.00        0.00        0.00
 Soil pH                  :        0.00        0.00        0.00        0.00
 Soil CACO3               :        0.00        0.00        0.00        0.00
                              
