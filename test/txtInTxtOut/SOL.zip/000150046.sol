 .Sol file Watershed HRU:498 Subbasin:15 HRU:46 Luse:RYEG Soil: CO567B Slope: 0-10.0 4/16/2025 12:00:00 AM ArcSWAT 2012.10_7.23
 Soil Name: CO567B
 Soil Hydrologic Group: B
 Maximum rooting depth(mm) : 1700.00
 Porosity fraction from which anions are excluded: 0.500
 Crack volume potential of soil: 0.500
 Texture 1                : FArA-ArA
 Depth                [mm]:      300.00     1700.00
 Bulk Density Moist [g/cc]:        1.53        1.63
 Ave. AW Incl. Rock Frag  :        0.32        0.32
 Ksat. (est.)      [mm/hr]:       20.92        3.50
 Organic Carbon [weight %]:        6.70        6.50
 Clay           [weight %]:       24.00       38.00
 Silt           [weight %]:       17.00       13.00
 Sand           [weight %]:       59.00       49.00
 Rock Fragments   [vol. %]:        1.00        1.00
 Soil Albedo (Moist)      :        0.13        0.13
 Erosion K                :        0.15        0.13
 Salinity (EC, Form 5)    :        0.00        0.00
 Soil pH                  :        0.00        0.00
 Soil CACO3               :        0.00        0.00
                              
